"use strict";

var _config = _interopRequireDefault(require("config"));

var _fs = _interopRequireDefault(require("fs"));

var _md5File = _interopRequireDefault(require("md5-file"));

var _jfrogClientJs = require("jfrog-client-js");

var _utils = require("./utils");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const USERNAME = _config.default.get('USERNAME');

const PASSWORD = _config.default.get('PASSWORD');

const URL = _config.default.get('URL');

const readApps = () => (0, _utils.readDirJSONFileContent)('apps').map(f => JSON.parse(f.content)).filter(a => a);

const isUpToDateJFROG = async (app, username, password) => {
  var _releases$results, _releases$results$;

  console.log(`Checking if ${app.path} is up to date..`);
  const filePathDownload = `downloads/${app.path}_${app.file}`;
  const filePathApp = `apps/${app.path}`;
  if (!_fs.default.existsSync(filePathDownload) || !_fs.default.existsSync(filePathApp)) return false;
  const md5 = await (0, _md5File.default)(filePathDownload);
  const jfrogClient = new _jfrogClientJs.JfrogClient({
    platformUrl: URL,
    username,
    password
  });
  const releases = await jfrogClient.artifactory().search().aqlSearch(`items.find({
      "repo":"${app.repo}",
      "path":{"$match":"*"},
      "name":"${app.file}"
    }).include("*").sort({"$desc":["updated","created"]}).limit(1)
  `);
  const md5Matches = md5 === (releases === null || releases === void 0 ? void 0 : (_releases$results = releases.results) === null || _releases$results === void 0 ? void 0 : (_releases$results$ = _releases$results[0]) === null || _releases$results$ === void 0 ? void 0 : _releases$results$.actual_md5);

  if (md5Matches) {
    console.log(`The md5 matched, No update needed.`);
  } else {
    var _releases$results2, _releases$results2$;

    console.log(`The md5 was not up to date. (current ${md5}, remote ${releases === null || releases === void 0 ? void 0 : (_releases$results2 = releases.results) === null || _releases$results2 === void 0 ? void 0 : (_releases$results2$ = _releases$results2[0]) === null || _releases$results2$ === void 0 ? void 0 : _releases$results2$.actual_md5})`);
  }

  return md5Matches;
};

const updateJFROG = async (app, username, password) => {
  console.log(`Updating ${app.path}...`);
  const filePathDownload = `downloads/${app.path}_${app.file}`;
  if (_fs.default.existsSync(filePathDownload)) _fs.default.rmSync(filePathDownload);
  const url = `"${URL}/artifactory/${app.repo}/${app.file}"`;
  await (0, _utils.exec)(`curl -J -L -H "Accept: application/octet-stream" -u ${username}:${password} ${url} -o ${filePathDownload}`);
  console.log(`Unpacking ${filePathDownload}...`);
  const dirPathBuild = `build/${app.path}`;
  if (_fs.default.existsSync(dirPathBuild)) _fs.default.rmSync(dirPathBuild, {
    recursive: true,
    force: true
  });
  await (0, _utils.exec)(`unzip -q ${filePathDownload} -d ${dirPathBuild}`);
  console.log(`Stopping any current running version of ${app.path}...`);
  await (0, _utils.stopPm2App)(app.path).catch(() => {});
  console.log(`Replacing ${app.path} with the new content...`);

  _fs.default.rmSync(`apps/${app.path}`, {
    recursive: true,
    force: true
  });

  _fs.default.renameSync(`${dirPathBuild}`, `apps/${app.path}`);

  console.log(`Starting ${app.path} with the new content...`);
  await (0, _utils.startPm2App)({
    name: app.path,
    script: `${app.main}`,
    cwd: `apps/${app.path}`,
    env: {
      NODE_CONFIG_DIR: `config`
    },
    instance_var: 'INSTANCE_ID'
  });
  console.log(`${app.path} started.`);
};

const ensureRunning = async app => {
  const runningApps = await (0, _utils.listPm2Apps)();
  const current = runningApps.find(a => a.name === app.path);
  if (current) return;
  await (0, _utils.startPm2App)({
    name: app.path,
    script: `${app.main}`,
    cwd: `apps/${app.path}`,
    env: {
      NODE_CONFIG_DIR: `config`
    },
    instance_var: 'INSTANCE_ID'
  });
};

const runOnce = async () => {
  const apps = readApps();
  if (!apps.length) return;
  await Promise.all(apps.map(async a => {
    if (await isUpToDateJFROG(a, USERNAME, PASSWORD)) return;
    await updateJFROG(a, USERNAME, PASSWORD);
    await ensureRunning(a);
  }));
};

const run = async () => {
  try {
    await runOnce();
  } catch (e) {
    console.log(e);
  }

  setTimeout(run, 60 * 5 * 1000);
};

run();