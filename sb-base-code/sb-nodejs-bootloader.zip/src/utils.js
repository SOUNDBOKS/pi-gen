"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.listPm2Apps = exports.startPm2App = exports.stopPm2App = exports.getFolderNames = exports.readDirJSONFileContent = exports.exec = exports.getSystemPath = void 0;

var _path = _interopRequireDefault(require("path"));

var _child_process = require("child_process");

var _fs = _interopRequireDefault(require("fs"));

var _pm = _interopRequireDefault(require("pm2"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const getSystemPath = unixPath => unixPath.replace('/', _path.default.delimiter);
/**
 * Executes shell command as it would happen in BASH script
 * @param {string} command
 * @param {Object} [options] Object with options. Set `capture` to TRUE, to capture and return stdout.
 *                           Set `echo` to TRUE, to echo command passed.
 * @returns {Promise<{code: number, data: string | undefined, error: Object}>}
 */


exports.getSystemPath = getSystemPath;

const exec = (command, {
  capture = false,
  echo = false
} = {}) => {
  if (echo) console.log(command);
  const childProcess = (0, _child_process.spawn)('bash', ['-c', command], {
    stdio: capture ? 'pipe' : 'inherit'
  });
  return new Promise((resolve, reject) => {
    let stdout = '';

    if (capture) {
      var _childProcess$stdout;

      childProcess === null || childProcess === void 0 ? void 0 : (_childProcess$stdout = childProcess.stdout) === null || _childProcess$stdout === void 0 ? void 0 : _childProcess$stdout.on('data', data => {
        stdout += data;
      });
    }

    childProcess.on('error', error => {
      reject({
        code: 1,
        error
      });
    });
    childProcess.on('close', code => {
      if (code > 0) reject({
        code: code,
        error: 'Command failed with code ' + code
      });else resolve({
        code,
        data: stdout
      });
    });
  });
};

exports.exec = exec;

const readDirJSONFileContent = path => _fs.default.readdirSync(path, {
  withFileTypes: true
}).filter(dirent => dirent.isFile() && dirent.name.endsWith('.json')).map(f => ({
  filename: f.name,
  content: _fs.default.readFileSync(`${path}/${f.name}`, {
    encoding: 'utf8'
  })
}));

exports.readDirJSONFileContent = readDirJSONFileContent;

const getFolderNames = path => _fs.default.readdirSync(path, {
  withFileTypes: true
}).filter(dirent => dirent.isDirectory()).map(f => f.name);

exports.getFolderNames = getFolderNames;

const stopPm2App = async name => new Promise((resolve, reject) => {
  _pm.default.stop(name, (err, proc) => {
    if (err) reject(err);
    resolve(proc);
  });
});

exports.stopPm2App = stopPm2App;

const startPm2App = async opts => new Promise((resolve, reject) => {
  _pm.default.start(opts, (err, proc) => {
    if (err) reject(err);
    resolve(proc);
  });
});

exports.startPm2App = startPm2App;

const listPm2Apps = async () => new Promise((resolve, reject) => {
  _pm.default.list((err, proc) => {
    if (err) reject(err);
    resolve(proc);
  });
});

exports.listPm2Apps = listPm2Apps;