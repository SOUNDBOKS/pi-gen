module.exports = {
  apps : [{
    name   : "bootloader",
    script : "./src/index.js",
    instance_var: 'INSTANCE_ID',
  }]
}
