"use strict";

var _ip = _interopRequireDefault(require("ip"));

var _config = _interopRequireDefault(require("config"));

var _sbStreamboksWs = require("@soundboks/sb-streamboks-ws");

var _types = require("@soundboks/sb-streamboks-ws/types");

var _package = _interopRequireDefault(require("../package.json"));

var _Stream = require("./Stream");

var _logger = _interopRequireDefault(require("./logger"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const logger = (0, _logger.default)('streamboks');

const URL = _config.default.get('WS.URL');

const ID = _config.default.get('WS.ID');

const RECONNECT_TIMEOUT = _config.default.get('WS.RECONNECT_TIMEOUT');

const OS = _config.default.get('OS');

const stream = new _Stream.Stream(); // Cleanup
// ===========

process.stdin.resume(); //so the program will not close instantly

const exitHandler = (options, exitCode) => {
  if (options.cleanup) {
    stream.stop();
  }

  if (exitCode || exitCode === 0) console.log(exitCode);
  if (options.exit) process.exit();
}; //do something when app is closing


process.on('exit', exitHandler.bind(null, {
  cleanup: true
})); //catches ctrl+c event

process.on('SIGINT', exitHandler.bind(null, {
  exit: true
})); // catches "kill pid" (for example: nodemon restart)

process.on('SIGUSR1', exitHandler.bind(null, {
  exit: true
}));
process.on('SIGUSR2', exitHandler.bind(null, {
  exit: true
})); //catches uncaught exceptions

process.on('uncaughtException', exitHandler.bind(null, {
  exit: true
})); // Cleanup end
// ===========

const ws = new _sbStreamboksWs.StreamboksWebSocket({
  id: ID,
  url: URL,
  reconnectTimeout: RECONNECT_TIMEOUT
});
ws.onopen(() => {
  logger.info('Connection opened.');
});
ws.onclose(() => {
  logger.info('Connection closed.');
  stream.stop();
});
ws.on(_types.CMD.START, async (_id, data) => {
  if (stream.isStarted()) return;
  stream.config({
    url: data.primary_server,
    key: data.stream_name,
    os: OS,
    authentication: data.username ? {
      username: data.username,
      password: data.password
    } : undefined
  });
  stream.start();
});
ws.on(_types.CMD.STOP, () => {
  if (stream.isStopped()) return;
  stream.stop();
});
ws.on(_types.CMD.STATUS, () => {
  const payload = {
    id: ID,
    status: stream.isStarted() ? _types.STATUS.LIVE : _types.STATUS.WAITING,
    version: _package.default.version,
    localIp: _ip.default.address()
  };
  ws.send({
    cmd: _types.CMD.STATUS,
    data: payload
  });
});