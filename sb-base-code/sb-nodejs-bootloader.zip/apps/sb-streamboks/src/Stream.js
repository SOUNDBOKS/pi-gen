"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Stream = void 0;

var _child_process = require("child_process");

var _ffmpegStatic = _interopRequireDefault(require("ffmpeg-static"));

var _logger = _interopRequireDefault(require("./logger"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const logger = (0, _logger.default)('Stream');
var StreamState;

(function (StreamState) {
  StreamState["STARTED"] = "started";
  StreamState["STOPPED"] = "stopped";
})(StreamState || (StreamState = {}));

;

class Stream {
  constructor(opts) {
    _defineProperty(this, "url", void 0);

    _defineProperty(this, "process", void 0);

    _defineProperty(this, "state", StreamState.STOPPED);

    _defineProperty(this, "os", void 0);

    if (opts) this.config(opts);
    this.ensureState();
  }

  isStarted() {
    return this.state === StreamState.STARTED;
  }

  isStopped() {
    return this.state === StreamState.STOPPED;
  }

  config(opts) {
    if (this.process) {
      logger.error('Can not configure as the stream is running. Please stop the stream before updating the config.');
      return;
    }

    const auth = opts.authentication ? `${opts.authentication.username}:${opts.authentication.password}@` : '';
    const uri = opts.url.split('//')[1];
    this.url = `rtmp://${auth}${uri}/${opts.key}`;
    this.os = opts.os;
    logger.info(`url set to ${this.url} and os set to ${this.os}`);
  }

  start() {
    if (this.process) return;

    if (!this.url) {
      logger.error('Cannot start as no configuration has been set yet.');
      return;
    }

    this.state = StreamState.STARTED;
    if (this.os === 'PI') this.runFfmpegPI();else this.runFfmpegOSX();
  }

  stop() {
    if (!this.process) return;
    this.state = StreamState.STOPPED;
    this.process.kill();
    this.process = undefined;
  }

  runFfmpegPI() {
    logger.info('starting PI stream...'); // console.log(`${ffmpeg} -hide_banner -loglevel error -f avfoundation -i ":0" -acodec aac -ab 48k -f flv ${this.url}`);
    // this.process = spawn(`${ffmpeg}`, ['-hide_banner', '-loglevel', 'debug', '-f', 'avfoundation', '-framerate', '60', '-i', 'none:0', '-c:a', 'libmp3lame', '-b:a', '48k', '-ar', '48000', '-f', 'flv', this.url]);
    // console.log(`/usr/local/bin/ffmpeg`, '-hide_banner', '-loglevel', 'debug', '-f', 'avfoundation', '-i', ':0', '-ar', '44100', '-b:a', '320k', '-sample_fmt', 's32', '-vn', '-preset', 'fast', '-f', 'flv', this.url)
    // this.process = spawn(`/usr/local/bin/ffmpeg`, ['-hide_banner', '-loglevel', 'debug', '-f', 'avfoundation', '-i', ':0', '-ar', '44100', '-b:a', '320k', '-sample_fmt', 's32', '-vn', '-preset', 'fast', '-f', 'flv', this.url]);

    this.process = (0, _child_process.spawn)('/usr/bin/ffmpeg', ['-hide_banner', '-loglevel', 'debug', '-f', 'alsa', '-i', 'hw:0', '-ar', '48000', '-b:a', '320k', '-vn', '-preset', 'fast', '-acodec', 'aac', '-f', 'flv', this.url]); // this.process = spawn(`${ffmpeg}`, ['-hide_banner', '-loglevel', 'debug', '-re', '-i', 'tash.flac', '-b:a', '320k', '-ar', '48000', '-f', 'flv', this.url]);
    // this.process = spawn(`${ffmpeg}`, ['-hide_banner', '-loglevel', 'debug', '-f', 'avfoundation', '-list_devices', 'true', '-i', '""']);

    this.process.stdout.setEncoding('utf8');
    this.process.stderr.setEncoding('utf8');
    this.process.stdout.on('data', data => logger.info(data));
    this.process.stderr.on('error', e => logger.error(e));
    this.process.stderr.on('data', d => logger.error(d));
    this.process.on('close', code => {
      logger.info(`Stopped PI with code ${code} (${this.url})`);
      this.process = undefined;
    });
  }

  runFfmpegOSX() {
    logger.info('starting OSX stream...'); // console.log(`${ffmpeg} -hide_banner -loglevel error -f avfoundation -i ":0" -acodec aac -ab 48k -f flv ${this.url}`);
    // this.process = spawn(`${ffmpeg}`, ['-hide_banner', '-loglevel', 'debug', '-f', 'avfoundation', '-framerate', '60', '-i', 'none:0', '-c:a', 'libmp3lame', '-b:a', '48k', '-ar', '48000', '-f', 'flv', this.url]);
    // console.log(`/usr/local/bin/ffmpeg`, '-hide_banner', '-loglevel', 'debug', '-f', 'avfoundation', '-i', ':0', '-ar', '44100', '-b:a', '320k', '-sample_fmt', 's32', '-vn', '-preset', 'fast', '-f', 'flv', this.url)
    // this.process = spawn(`/usr/local/bin/ffmpeg`, ['-hide_banner', '-loglevel', 'debug', '-f', 'avfoundation', '-i', ':0', '-ar', '44100', '-b:a', '320k', '-sample_fmt', 's32', '-vn', '-preset', 'fast', '-f', 'flv', this.url]);

    this.process = (0, _child_process.spawn)(`${_ffmpegStatic.default}`, ['-hide_banner', '-loglevel', 'debug', '-f', 'alsa', '-i', 'hw:0', '-ar', '48000', '-b:a', '320k', '-vn', '-preset', 'fast', '-acodec', 'aac', '-f', 'flv', this.url]); // this.process = spawn(`${ffmpeg}`, ['-hide_banner', '-loglevel', 'debug', '-re', '-i', 'tash.flac', '-b:a', '320k', '-ar', '48000', '-f', 'flv', this.url]);
    // this.process = spawn(`${ffmpeg}`, ['-hide_banner', '-loglevel', 'debug', '-f', 'avfoundation', '-list_devices', 'true', '-i', '""']);

    this.process.stdout.setEncoding('utf8');
    this.process.stderr.setEncoding('utf8');
    this.process.stdout.on('data', data => logger.info(data));
    this.process.stderr.on('error', e => logger.error(e));
    this.process.stderr.on('data', d => logger.error(d));
    this.process.on('close', code => {
      logger.info(`Stopped OSX with code ${code} (${this.url})`);
      this.process = undefined;
    });
  }

  ensureState() {
    setTimeout(() => {
      if (this.process && this.isStopped()) this.stop();else if (!this.process && this.isStarted()) this.start();
      this.ensureState();
    }, 30000);
  }

}

exports.Stream = Stream;