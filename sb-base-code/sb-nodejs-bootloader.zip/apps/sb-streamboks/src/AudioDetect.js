"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AudioDetect = void 0;

var _mic = _interopRequireDefault(require("mic"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class AudioDetect {
  constructor() {
    _defineProperty(this, "micInstance", void 0);

    this.micInstance = (0, _mic.default)({
      rate: '16000',
      channels: '1',
      debug: true,
      exitOnSilence: 6
    });
  }

  async isSilent() {
    return new Promise((resolve, _reject) => {
      const micInputStream = this.micInstance.getAudioStream();
      micInputStream.on('data', function (data) {
        console.log("Recieved Input Stream: " + data.length);
      });
      micInputStream.on('error', function (err) {
        console.log("Error in Input Stream: " + err);
      });
      micInputStream.on('startComplete', function () {
        console.log("Got SIGNAL startComplete");
      });
      micInputStream.on('stopComplete', function () {
        console.log("Got SIGNAL stopComplete");
      });
      micInputStream.on('pauseComplete', function () {
        console.log("Got SIGNAL pauseComplete");
      });
      micInputStream.on('resumeComplete', function () {
        console.log("Got SIGNAL resumeComplete");
      });
      micInputStream.on('silence', function () {
        console.log("Got SIGNAL silence");
      });
      micInputStream.on('processExitComplete', function () {
        console.log("Got SIGNAL processExitComplete");
      });
      setTimeout(() => resolve(true), 5 * 1000);
    });
  }

}

exports.AudioDetect = AudioDetect;