"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.LogLevel = void 0;
let LogLevel;
exports.LogLevel = LogLevel;

(function (LogLevel) {
  LogLevel[LogLevel["DEBUG"] = 0] = "DEBUG";
  LogLevel[LogLevel["INFO"] = 1] = "INFO";
  LogLevel[LogLevel["WARN"] = 2] = "WARN";
  LogLevel[LogLevel["ERROR"] = 3] = "ERROR";
})(LogLevel || (exports.LogLevel = LogLevel = {}));

;

const log = (prefix, f) => (message, ...optionalParams) => {
  f(`${prefix}: ${message}`, ...optionalParams);
};

const hide = () => (_message, ..._optionalParams) => {};

var _default = (prefix, level = LogLevel.INFO) => ({
  error: level <= LogLevel.ERROR ? log(prefix, console.error) : hide(),
  warn: level <= LogLevel.WARN ? log(prefix, console.warn) : hide(),
  info: level <= LogLevel.INFO ? log(prefix, console.info) : hide(),
  debug: level === LogLevel.DEBUG ? log(prefix, console.debug) : hide()
});

exports.default = _default;