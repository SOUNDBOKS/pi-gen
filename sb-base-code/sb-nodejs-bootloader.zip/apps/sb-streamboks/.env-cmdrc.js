const fs = require('fs');

const ENV_FOLDER = `${__dirname}/env`;
const isEnv = /.env.+.js/;

/**
 * Scans for files with the format env.<name>.js within
 * the current folder and loads them into a config object
 */
const loadEnvironments = () =>
  fs.readdirSync(ENV_FOLDER).reduce((acc, f) => {
    if (isEnv.test(f)) {
      const name = f.split('.')[2];

      return {
        ...acc,
        [name]: require(`${ENV_FOLDER}/${f}`),
      };
    }

    return acc;
  }, {});

/**
 * Export all of the modified environments
 */
module.exports = loadEnvironments();
