const testEnv = require('./.env.test.js');

/**
 * Test environment
 */
module.exports = {
  ...testEnv,

  // Change the host to the name of the docker container
  PRISMA_HOST: 'db',
}
