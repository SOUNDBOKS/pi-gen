const localEnv = require('./.env.local.js');

/**
 * Test environment
 */
module.exports = {
  ...localEnv,

  // Change the host to the name of the docker container
  PRISMA_HOST: 'db',
}
