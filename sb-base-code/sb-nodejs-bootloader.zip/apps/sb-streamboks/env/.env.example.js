/**
 * Example environment
 */
module.exports = {
  // NODE_ENV: 'development',
  // BINARY_TARGET: 'native',

  // Datadog
  // DATADOG_API_KEY: 'place_holder'

  // Prisma
  // PRISMA_HOST: 'localhost',
  // PRISMA_USERNAME: 'sk_user',
  // PRISMA_PASSWORD: 'sk_password_root',
  // PRISMA_DATABASE: 'SBAuthDB_dev',
  // PRISMA_PORT: '5432,
  // BINARY_TARGET: 'native', // rhel-openssl-1.0.x for Lambda

  // AWS
  // AWS_ACCESS_KEY: '',
  // AWS_SECRET_KEY: '',
  // AWS_DEFAULT_REGION: 'eu-west-1'

  // Secret
  // TOKEN_SECRET: ''

  // Activate if you want to run tests against an external server (eg: a docker container)
  // TEST_EXTERNAL_SERVER: true,
};
